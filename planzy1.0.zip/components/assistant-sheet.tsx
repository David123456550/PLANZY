"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, Bot, User, Loader2 } from "lucide-react"
import { PlanzyLogo } from "./planzy-logo"
import { useAppStore } from "@/lib/store"
import { useTranslation } from "@/lib/i18n"

interface AssistantSheetProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
}

export function AssistantSheet({ open, onOpenChange }: AssistantSheetProps) {
  const { language } = useAppStore()
  const t = useTranslation(language)
  const scrollRef = useRef<HTMLDivElement>(null)
  const [isTyping, setIsTyping] = useState(false)

  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: t.assistantWelcome,
    },
  ])
  const [input, setInput] = useState("")

  useEffect(() => {
    if (scrollRef.current) {
      const scrollElement = scrollRef.current.querySelector("[data-radix-scroll-area-viewport]")
      if (scrollElement) {
        scrollElement.scrollTop = scrollElement.scrollHeight
      }
    }
  }, [messages])

  const getAssistantResponse = (userMessage: string): string => {
    const msg = userMessage.toLowerCase()

    if (msg.includes("crear") || msg.includes("plan") || msg.includes("create")) {
      return language === "es"
        ? "Para crear un plan, pulsa el botón '+' en la barra inferior. Rellena el título, descripción, categoría, fecha, hora y ubicación. ¡Todos los campos son obligatorios!"
        : "To create a plan, tap the '+' button in the bottom bar. Fill in the title, description, category, date, time, and location. All fields are required!"
    }

    if (msg.includes("unir") || msg.includes("apuntar") || msg.includes("join")) {
      return language === "es"
        ? "Para unirte a un plan, abre los detalles del plan y pulsa 'Apuntarme'. Si el plan tiene coste, podrás pagar con tarjeta o con el saldo de tu monedero."
        : "To join a plan, open the plan details and tap 'Join'. If the plan has a cost, you can pay with card or your wallet balance."
    }

    if (msg.includes("monedero") || msg.includes("wallet") || msg.includes("dinero") || msg.includes("money")) {
      return language === "es"
        ? "Tu monedero virtual guarda el dinero de reembolsos cuando cancelas planes pagados. También recibes dinero cuando alguien se une a tus planes de pago. Puedes retirar el dinero a tu cuenta bancaria sin comisión."
        : "Your virtual wallet stores refund money when you cancel paid plans. You also receive money when someone joins your paid plans. You can withdraw to your bank account with no commission."
    }

    if (msg.includes("chat") || msg.includes("mensaje") || msg.includes("message")) {
      return language === "es"
        ? "Cuando te unes a un plan, puedes acceder al chat del grupo. También puedes enviar mensajes privados a otros usuarios desde su perfil."
        : "When you join a plan, you can access the group chat. You can also send private messages to other users from their profile."
    }

    if (msg.includes("buscar") || msg.includes("search") || msg.includes("filtrar") || msg.includes("filter")) {
      return language === "es"
        ? "En la pestaña de búsqueda puedes filtrar planes por intereses, ubicación, nombre del plan o nombre de usuario. ¡Encuentra exactamente lo que buscas!"
        : "In the search tab you can filter plans by interests, location, plan name, or username. Find exactly what you're looking for!"
    }

    if (msg.includes("verificar") || msg.includes("verify") || msg.includes("verificación")) {
      return language === "es"
        ? "Puedes verificar tu identidad en Ajustes > Verificación. Sube una selfie con tu DNI para obtener la insignia de verificado y generar más confianza."
        : "You can verify your identity in Settings > Verification. Upload a selfie with your ID to get the verified badge and build more trust."
    }

    if (msg.includes("bloquear") || msg.includes("block") || msg.includes("denunciar") || msg.includes("report")) {
      return language === "es"
        ? "Puedes bloquear o denunciar a un usuario desde su perfil. Pulsa los tres puntos arriba a la derecha para ver estas opciones."
        : "You can block or report a user from their profile. Tap the three dots at the top right to see these options."
    }

    // Default responses
    const defaultResponses =
      language === "es"
        ? [
            "¡Interesante pregunta! ¿Hay algo específico sobre Planzy en lo que pueda ayudarte?",
            "Puedo ayudarte con: crear planes, unirte a planes, gestionar tu monedero, usar el chat, buscar planes, verificar tu cuenta, y más. ¿Qué te gustaría saber?",
            "¿Te gustaría que te explique cómo funciona alguna función de Planzy? Estoy aquí para ayudarte.",
          ]
        : [
            "Interesting question! Is there something specific about Planzy I can help you with?",
            "I can help you with: creating plans, joining plans, managing your wallet, using chat, searching plans, verifying your account, and more. What would you like to know?",
            "Would you like me to explain how any Planzy feature works? I'm here to help.",
          ]

    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)]
  }

  const handleSend = () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: getAssistantResponse(input),
      }
      setMessages((prev) => [...prev, assistantMessage])
      setIsTyping(false)
    }, 1000)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="flex w-full flex-col sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <PlanzyLogo size="sm" showText={false} />
            {t.aiAssistant}
          </SheetTitle>
        </SheetHeader>

        {/* Messages */}
        <ScrollArea ref={scrollRef} className="flex-1 py-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex gap-3 ${message.role === "user" ? "flex-row-reverse" : ""}`}>
                <Avatar className="h-8 w-8 flex-shrink-0">
                  <AvatarFallback
                    className={message.role === "assistant" ? "bg-[#1a95a4] text-white" : "bg-[#ef7418] text-white"}
                  >
                    {message.role === "assistant" ? <Bot className="h-4 w-4" /> : <User className="h-4 w-4" />}
                  </AvatarFallback>
                </Avatar>
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${
                    message.role === "user" ? "bg-[#ef7418] text-white" : "bg-muted"
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex gap-3">
                <Avatar className="h-8 w-8 flex-shrink-0">
                  <AvatarFallback className="bg-[#1a95a4] text-white">
                    <Bot className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="rounded-2xl px-4 py-2.5 bg-muted">
                  <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="flex gap-2 border-t pt-4">
          <Input
            placeholder={t.askAssistant}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyPress}
          />
          <Button
            size="icon"
            className="bg-[#ef7418] hover:bg-[#ef7418]/90 text-white"
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}
